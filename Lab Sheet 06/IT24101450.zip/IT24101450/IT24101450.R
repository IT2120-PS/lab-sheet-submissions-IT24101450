setwd('C:\\Users\\IT24101450\\Desktop\\IT24101450')
getwd()

##Part-1
#i)
#Binomial Distribution

#ii)
#P(X>=47) = 1-P(X<=46)
1-pbinom(46,50,0.85,TRUE)

##Part-2
#i)
#X= Number of calls received in one hour

#ii)
#Poisson Distribution


#iii)
#X=15
dpois(15,12)

